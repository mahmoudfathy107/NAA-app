<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Donate;
use Illuminate\Support\Facades\Auth;
use Mail;
use App\Mail\ContactusMail;

class DonateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $email = $request->email;
        $message = $request->message;
        return view('NAA-Donate.Donate', compact('email', 'message'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $email = $request->email;
        $message = $request->message;
        if (request('id')) {
             $payment_status = $this->getPaymentStatus(request('id'));
             if (isset($payment_status['id'])) { //success payment id -> transaction bank id
                 $showSuccessPaymentMessage = true;
                 $user = Auth::user();

                 $data = new Donate();
                 $data->user_id = Auth()->id();
                 $data->name = $payment_status["card"]["holder"];
                 $data->email = $request->email;
                 $data->message = $request->message;
                 $data->workWithUs = $request->category1;
                 $data->getLegalAdvice = $request->category2;
                 $data->advirtiseWithUs = $request->category3;
                 $data->publishWithUs = $request->category4;
                 $data->takePicture = $request->category5;
                 $data->Donate = $request->category6;
                 $data->WatchEpisodes = $request->category7;
                 $data->butAbook = $request->category8;
                 $data->translate = $request->category9;
                 $data->other = $request->category10;
                 $data->transactionId = $payment_status['id'];
                 $data->paymentBrand = $payment_status['paymentBrand'];
                 $data->amount = $payment_status['amount'];
                 $data->currency = $payment_status['currency'];
                 $data->result = $payment_status['result']['description'];
                 $mailData = [
                     'subject' => 'NAA App Message',
                     'title' => $payment_status["card"]["holder"],
                     'body' => $request->message,
                 ];

                 Mail::to('mahmoudfathy107@gmail.com')->send(new ContactusMail($mailData));
                 $data->save();
                 //save order in orders table with transaction id  = $payment_status['id']
               return view('NAA-Donate.create', compact('email', 'message'))-> with(['success' =>  'تم الدفغ بنجاح']);
           } else {
               $showFailPaymentMessage = true;
                return view('NAA-Donate.create')-> with(['fail'  => 'فشلت عملية الدفع']);
           }

       }

       return view('NAA-Donate.create', compact('email', 'message'));

    }


    function getPaymentStatus($id){
        $url = "https://test.oppwa.com/v1/checkouts/$id/payment";
	    $url .= "?entityId=8a8294174b7ecb28014b9699220015ca";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Authorization:Bearer OGE4Mjk0MTc0YjdlY2IyODAxNGI5Njk5MjIwMDE1Y2N8c3k2S0pzVDg='));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);// this should be set to true in production
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $responseData = curl_exec($ch);
        if(curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);

        return json_decode($responseData, true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
